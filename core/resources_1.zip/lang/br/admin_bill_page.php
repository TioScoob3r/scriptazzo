<?php

return [
    'admin_bill_transactions' => "Transações",
    'admin_bill_sn' => "Cód",
    'admin_bill_username' => "Nome de Usuário",
    'admin_bill_network' => "Rede",
    'admin_bill_amount' => "Valor",
    'admin_bill_charge' => "Taxa",
    'admin_bill_recharge_id' => "Id da Recarga",
    'admin_bill_reference' => "Referência",
    'admin_bill_date' => "Data"
];