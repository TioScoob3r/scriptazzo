<?php

return [
    'virtual_' => "Virtual"
];