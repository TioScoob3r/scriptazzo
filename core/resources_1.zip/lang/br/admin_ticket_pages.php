<?php

return [
    'virtual_1' => "Virtual"
];