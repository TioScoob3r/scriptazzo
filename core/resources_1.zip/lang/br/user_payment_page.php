<?php

return [
    "payment_please_send_exact" => "POR FAVOR, ENVIE EXATAMENTE",
    "payment_to" => "PARA",
    "payment_your_account_will_be_credited" => "Sua conta será creditada automaticamente após 2 confirmações",
    "payment_pay_with_flutterwave" => "Pagar com Flutterwave",
    "payment_charge" => "Cobrança",
    "payment_pay_with_paystack" => "Pagar com Paystack"
];

