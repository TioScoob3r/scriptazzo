<?php

return [
    'admin_bill_transactions' => "Transactions",
    'admin_bill_sn' => "S / N",
    'admin_bill_username' => "Username",
    'admin_bill_network' => "Network",
    'admin_bill_amount' => "Amount",
    'admin_bill_charge' => "Charge",
    'admin_bill_recharge_id' => "Recharge id",
    'admin_bill_reference' => "Reference",
    'admin_bill_date' => "Date"
];