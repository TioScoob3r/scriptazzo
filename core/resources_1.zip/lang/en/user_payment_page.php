<?php

return [
    "payment_please_send_exact" => "PLEASE SEND EXACTLY",
    "payment_to" => "TO",
    "payment_your_account_will_be_credited" => "Your account will be credited upon 2 confirmations automatically",
    "payment_pay_with_flutterwave" => "Pay with Flutterwave",
    "payment_charge" => "Charge",
    "payment_pay_with_paystack" => "Pay with Paystack"
];

