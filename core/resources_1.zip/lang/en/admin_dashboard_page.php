<?php

return [
    'admin_dashboard_users' => "Users",
    'admin_dashboard_active_blocked' => "Active/Blocked users",
    'admin_dashboard_single_charge' => "Single Charge",
    'admin_dashboard_amount_charge' => "Amount/Charges:",
    'admin_dashboard_donations' => "Donations",
    'admin_dashboard_merchant' => "Merchant",
    'admin_dashboard_invoice' => "Invoice",
    'admin_dashboard_request_money' => "Request Money",
    'admin_dashboard_settlement' => "Settlement",
    'admin_dashboard_funding_account' => "Funding account",
    'admin_dashboard_product_order' => "Product Order",
    'admin_dashboard_transfers' => "Transfers"
];