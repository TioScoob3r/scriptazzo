<?php

return [
    "shop_layout_close" => "Close",
    "shop_layout_back" => "Back",
    "shop_layout_set_up_your_store_for_free" => "SET UP YOUR STORE FOR FREE",
    "shop_layout_shopping_cart" => "SHOPPING CART",
    "shop_layout_subtotal" => "SUBTOTAL",
    "shop_layout_proceed_to_checkout" => "PROCEED TO CHECKOUT",
    "shop_layout_home" => "Home",
    "shop_layout_by" => "By",
    "shop_layout_phone" => "Phone",
    "shop_layout_email" => "E-mail"
];