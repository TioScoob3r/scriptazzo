<?php

return [
    "shop_layout_close" => "Fechar",
    "shop_layout_back" => "Voltar",
    "shop_layout_set_up_your_store_for_free" => "CONFIGURE GRÁTIS SUA LOJA",
    "shop_layout_shopping_cart" => "CARRINHO DE COMPRAS",
    "shop_layout_subtotal" => "SUBTOTAL",
    "shop_layout_proceed_to_checkout" => "SEGUIR PARA O PAGAMENTO",
    "shop_layout_home" => "Início",
    "shop_layout_by" => "Por",
    "shop_layout_phone" => "Telefone",
    "shop_layout_email" => "E-mail"
];