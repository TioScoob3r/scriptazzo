<?php

return [
    'admin_dashboard_users' => "Usuários",
    'admin_dashboard_active_blocked' => "Usuários Ativos/Bloqueados",
    'admin_dashboard_single_charge' => "Links de Pagamento",
    'admin_dashboard_amount_charge' => "Valor/Taxas:",
    'admin_dashboard_donations' => "Doações",
    'admin_dashboard_merchant' => "Comerciante",
    'admin_dashboard_invoice' => "Faturas",
    'admin_dashboard_request_money' => "Solicitação de Pagamento",
    'admin_dashboard_settlement' => "Ciclo de Pagamento",
    'admin_dashboard_funding_account' => "Recargas na Conta",
    'admin_dashboard_product_order' => "Ordens de Produtos",
    'admin_dashboard_transfers' => "Transferências"
];